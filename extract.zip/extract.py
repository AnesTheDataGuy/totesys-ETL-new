def extract():
    pass