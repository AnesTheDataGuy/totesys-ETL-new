def load():
    pass